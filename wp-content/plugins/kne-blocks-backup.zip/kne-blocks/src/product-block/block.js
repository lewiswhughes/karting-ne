const { __ } = wp.i18n; // Import __() from wp.i18n
const { RichText, PlainText, InspectorControls, InnerBlocks } = wp.editor;
const { registerBlockType } = wp.blocks;
const { SelectControl, TextControl } = wp.components;
const { Component } = wp.element;

//EDIT POSTS CLASS (REACT COMPONENT)
class mySelectPosts extends Component {
	// Method for setting the initial state.
  static getInitialState( selectedPost ) {
    return {
      posts: [],
      selectedPost: selectedPost,
      post: {}
    };
  }
  // Constructing our component. With super() we are setting everything to 'this'.
  // Now we can access the attributes with this.props.attributes
  constructor() {
    super(...arguments);
    // Maybe we have a previously selected post. Try to load it.
    this.state = this.constructor.getInitialState( this.props.attributes.selectedPost );
		// Bind so we can use 'this' inside the method.
    this.getOptions = this.getOptions.bind(this);
    // Load posts.
    this.getOptions();
		//bind functions
		this.onChangeSelectPost = this.onChangeSelectPost.bind(this);
  }

	/**
  * Loading Posts
  */
  getOptions() {
    return fetch('/wp-json/wp/v2/product/?per_page=50') 
		.then( response => response.json() )
		.then( ( posts ) => {
      if( posts && 0 !== this.state.selectedPost ) {
        // If we have a selected Post, find that post and add it.
        const post = posts.find( ( item ) => { return item.id == this.state.selectedPost } );
        // This is the same as { post: post, posts: posts }
        this.setState( { post, posts } );
      } else {
        this.setState({ posts });
      }
    });
  }

	onChangeSelectPost( value ) {
    // Find the post
    const post = this.state.posts.find( ( item ) => { return item.id == parseInt( value ) } );

    console.log(post);
    // Set the state
    this.setState( { selectedPost: parseInt( value ), post } );
    // Set the attributes
    this.props.setAttributes( {
      selectedPost: parseInt( value ),
      title: post.title.rendered,
      link: post.link,
      minAge: post.acf.minimum_age,
      maxAge: post.acf.maximum_age,
      notBookable: post.acf['not-bookable'],
      shortDescription: post.excerpt.rendered
    });
  }

  render() {
		let options = [ { value: 0, label: __( 'Select a Post' ) } ];
		let output  = __( 'Loading Posts' );
		this.props.className += ' loading';
    if( this.state.posts.length > 0 ) {
      const loading = __( 'We have %d posts. Choose one.' );
      output = loading.replace( '%d', this.state.posts.length );
      this.state.posts.forEach((post) => {
        options.push({value:post.id, label:post.title.rendered});
      });
		} else {
		 output = __( 'No posts found. Please create some first.' );
		}

    //prices elements
    let priceOneLabel = ( this.props.attributes.priceOneLabel.length > 0 ) ? <label>{ this.props.attributes.priceOneLabel }</label> : null ;
    let priceOne = ( this.props.attributes.priceOne.length > 0 ) ? <p>{ this.props.attributes.priceOne }</p> : null ;
    let priceTwoLabel = ( this.props.attributes.priceTwoLabel.length > 0 ) ? <label>{ this.props.attributes.priceTwoLabel }</label> : null ;
    let priceTwo = ( this.props.attributes.priceTwo.length > 0 ) ? <p>{ this.props.attributes.priceTwo }</p> : null ;

    let prices = [];
    let priceContOne = [];
    let priceContTwo = [];
    let pricesOne = null;
    let pricesTwo = null;
    if( priceOneLabel ){
      priceContOne.push( priceOneLabel );
    }
    if( priceOne ){
      priceContOne.push( priceOne );
    }
    if( priceTwoLabel ){
      priceContTwo.push( priceTwoLabel );
    }
    if( priceTwo ){
      priceContTwo.push( priceTwo );
    }
    if( priceContOne.length > 0 ){
      pricesOne = <div>{priceContOne}</div>;
    }
    if( priceContTwo.length > 0 ){
      pricesTwo = <div>{priceContTwo}</div>;
    }
    prices.push( pricesOne );
    prices.push( pricesTwo );

    let bookingText = ( this.props.attributes.notBookable ) ? 'Call to book' : 'Book Now' ;

    let ageBlock = null;
    if( this.props.attributes.minAge > 0 ){
      if( parseInt(this.props.attributes.maxAge, 10) > parseInt(this.props.attributes.minAge, 10) ){
        ageBlock = <div className="ages">{this.props.attributes.minAge} - {this.props.attributes.maxAge} Yrs</div>;
      } else {
        ageBlock = <div className="ages">{this.props.attributes.minAge}+ Yrs</div>;
      }
    }

		// Checking if we have anything in the object
    if( this.state.post.hasOwnProperty('title') ) {
      output = <article className="event">
					<div>
						<h2 dangerouslySetInnerHTML={ { __html: this.state.post.title.rendered } }></h2>
					</div>
          <div className="prices">
            {prices}
          </div>
					<div>
            <div dangerouslySetInnerHTML={ { __html: this.state.post.excerpt.rendered } }></div>
						<a href={ this.state.post.id }>{bookingText}</a>
            { ageBlock }
					</div>
        </article>;
      this.props.className += ' has-post';
    } else {
      this.props.className += ' no-post';
    }

    return [
    // If we are focused on this block, create the inspector controls.
      !! this.props.isSelected && (
				<InspectorControls key="inspector">
				<SelectControl
				onChange={this.onChangeSelectPost}
        // Selected value.
        value={ this.props.attributes.selectedPost }
        label={ __( 'Select a Post' ) }
        options={ options } />
        <TextControl
          label='Price One Label'
          value={ this.props.attributes.priceOneLabel }
          onChange={ (value) => {
            this.setState({ priceOneLabel: value });
            this.props.setAttributes({ priceOneLabel: value });
          } }
        />
        <TextControl
          label='Price One'
          value={ this.props.attributes.priceOne }
          onChange={ (value) => {
            this.setState({ priceOne: value });
            this.props.setAttributes({ priceOne: value });
          } }
        />
        <TextControl
          label='Price Two label'
          value={ this.props.attributes.priceTwoLabel }
          onChange={ (value) => {
            this.setState({ priceTwoLabel: value });
            this.props.setAttributes({ priceTwoLabel: value });
          } }
        />
        <TextControl
          label='Price Two'
          value={ this.props.attributes.priceTwo }
          onChange={ (value) => {
            this.setState({ priceTwo: value });
            this.props.setAttributes({ priceTwo: value });
          } }
        />
				</ InspectorControls >
      ),
    	<section className={this.props.className}>{output}</section>
    ]

  }
}


registerBlockType('kne/product-block', {
  title: __( 'KNE Product Block' ),
  icon: 'heart',
  category: 'common',
  attributes: {
    title: {
      type: 'string',
      selector: 'h2'
    },
    link: {
      type: 'string',
      selector: 'a'
    },
    selectedPost: {
      type: 'number',
      default: 0
    },
    minAge: {
      type: 'string',
      default: 14
    },
    notBookable: {
      type: 'boolean',
      default: false
    },
    maxAge: {
      type: 'string',
      default: 0
    },
    shortDescription: {
      type: 'string'
    },
    priceOneLabel: {
      type: 'string',
      default: ''
    },
    priceOne: {
      type: 'string',
      default: ''
    },
    priceTwoLabel: {
      type: 'string',
      default: ''
    },
    priceTwo: {
      type: 'string',
      default: ''
    }
  },

  edit: mySelectPosts,

  save: function( props ) {

    //prices elements
    let priceOneLabel = ( props.attributes.priceOneLabel.length > 0 ) ? <label>{ props.attributes.priceOneLabel }</label> : null ;
    let priceOne = ( props.attributes.priceOne.length > 0 ) ? <p>{ props.attributes.priceOne }</p> : null ;
    let priceTwoLabel = ( props.attributes.priceTwoLabel.length > 0 ) ? <label>{ props.attributes.priceTwoLabel }</label> : null ;
    let priceTwo = ( props.attributes.priceTwo.length > 0 ) ? <p>{ props.attributes.priceTwo }</p> : null ;

    let prices = [];
    let priceContOne = [];
    let priceContTwo = [];
    let pricesOne = null;
    let pricesTwo = null;
    if( priceOneLabel ){
      priceContOne.push( priceOneLabel );
    }
    if( priceOne ){
      priceContOne.push( priceOne );
    }
    if( priceTwoLabel ){
      priceContTwo.push( priceTwoLabel );
    }
    if( priceTwo ){
      priceContTwo.push( priceTwo );
    }
    if( priceContOne.length > 0 ){
      pricesOne = <div>{priceContOne}</div>;
    }
    if( priceContTwo.length > 0 ){
      pricesTwo = <div>{priceContTwo}</div>;
    }
    prices.push( pricesOne );
    prices.push( pricesTwo );

    let bookingLink = ( props.attributes.notBookable ) ? 'tel:01915214050' : '/booking-start/?prod=' + props.attributes.selectedPost ;
    let bookingText = ( props.attributes.notBookable ) ? 'Call to book' : 'Book Now' ;

    let ageBlock = null;
    if( props.attributes.minAge > 0 ){
      if( parseInt(props.attributes.maxAge, 10) > parseInt(props.attributes.minAge, 10) ){
        ageBlock = <div className="ages">{props.attributes.minAge} - {props.attributes.maxAge} Yrs</div>;
      } else {
        ageBlock = <div className="ages">{props.attributes.minAge}+ Yrs</div>;
      }
    }

    return (
      <article className="event">
        <div>
          <h2 dangerouslySetInnerHTML={ { __html: props.attributes.title } }></h2>
        </div>
        <div className="prices">
          {prices}
        </div>
				<div>
          <div dangerouslySetInnerHTML={ { __html: props.attributes.shortDescription } }></div>
					<a href={bookingLink}>{bookingText}</a>
          {ageBlock}
				</div>
      </article>
    );
	}


});
