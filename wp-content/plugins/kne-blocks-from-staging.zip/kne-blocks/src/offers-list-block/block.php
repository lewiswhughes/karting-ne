<?php
// block.php

function render_block_offers_list() {

    $offer_content = '';

    $args = array(
      'post_type' => 'offer'
    );
    $offers_query = new WP_Query( $args );
    $offers = $offers_query->posts;

    foreach( $offers as $offer ){

      $offer_id = $offer->ID;
      $offer_post = get_post( $offer_id );
      $offer_type = get_field( 'offer_type', $offer_id );
      $offer_event = ( $offer_type == 'event' ) ? get_field( 'event_link', $offer_id ) : null ;

      $offer_content.= '<article class="offer">';
      $offer_content.='<h2>'.$offer->post_title.'</h2>';
      $offer_content.='<p>'.get_field( 'summary_text', $offer_id ).'</p>';
      //more information
      $offer_content.='<details class="more-info">
        <summary>More information</summary>';
      $offer_content.= apply_filters( 'the_content', $offer_post->post_content );
      $offer_content.='</details>';
      //mterms and conditions
      $offer_content.='<details class="t-and-c">
        <summary>Terms &amp; conditions</summary>';
      $offer_content.= '<p>'.get_field( 'terms_and_conditions', $offer_id ).'</p>';
      $offer_content.='</details>';
      //event button
      if( $offer_event ){
        $link = '/booking-start/?prod='.$offer_event->ID;
        $offer_content.='<a class="link_button" href="'.$link.'">Book now</a>';
      }
      $offer_content.='</article>';
    }

    return '<section class="offers-list">'.$offer_content.'</section>';
}

register_block_type( 'kne/offers-list-block', array(
    'render_callback' => 'render_block_offers_list',
) );
