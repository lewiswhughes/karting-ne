const { __ } = wp.i18n; // Import __() from wp.i18n
const { InspectorControls, ColorPalette } = wp.editor;
const { registerBlockType } = wp.blocks;
const { SelectControl, PanelBody } = wp.components;
const { Fragment } = wp.element;

import Icons from './icons.js';

registerBlockType('kne/icons-block', {
  title: 'KNE Icons',
  icon: 'heart',
  category: 'common',
  attributes: {
    svgName: {
      default: null,
  		type: 'string'
  	},
    svgText: {
      default: 'Icon here',
  		type: 'string'
    },
    iconColor: {
      default: '#000000',
      type: 'string'
    }
  },

  edit( { attributes, setAttributes } ) {

    const options = Icons.map( icon => {
      return {value: icon.name, label: icon.label};
    });

    const setSvg = function( svgName, color ){

      let svgObj = Icons.find( (icon) => { return icon.name === svgName } );

      setAttributes({
        svgName: svgName,
        svgText: svgObj.svgText( color )
      })
    };

    const updateColor = function( color ){
      setAttributes({ iconColor: color });
      setSvg( attributes.svgName, color );
    }

    return[
			<InspectorControls key="inspector">
				<SelectControl
				onChange={ (value) => setSvg( value, attributes.iconColor ) }
        // Selected value.
        value={ attributes.svgName }
        label={ __( 'Select an Icon to display' ) }
        options={ options } />
        <ColorPalette
          label='Select Icon Colour:'
          value={ attributes.iconColor }
          onChange={ color => updateColor( color ) }
        />
      </ InspectorControls >,
    	<div className="svg-container" dangerouslySetInnerHTML={ { __html: attributes.svgText } }></div>
    ]

  },


  save( { attributes } ) {
    return <div className="svg-container" dangerouslySetInnerHTML={ { __html: attributes.svgText } }></div>;
  }


});
