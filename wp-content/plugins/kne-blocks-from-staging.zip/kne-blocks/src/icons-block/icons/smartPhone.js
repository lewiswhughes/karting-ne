const svgText = function( color ){
  return `<svg xmlns="http://www.w3.org/2000/svg" width="37" height="74.112" viewBox="0 0 37 74.112">
  <path id="Path_351" data-name="Path 351" d="M13.9,3.363c-.246,0-.446.325-.446.744v.2c0,.412.2.744.446.744h9.2c.246,0,.446-.325.446-.744v-.2c0-.412-.2-.744-.446-.744H13.9Zm4.6,67.946a3.363,3.363,0,1,0-3.363-3.365A3.363,3.363,0,0,0,18.5,71.309ZM3.363,8.408V62.225H33.635V8.408ZM0,6.737V67.375c0,6.737,6.728,6.737,6.728,6.737H30.272S37,74.112,37,67.375V6.737C37,0,30.272,0,30.272,0H6.728S0,0,0,6.737Z" fill="` + color + `" fill-rule="evenodd"/>
  </svg>`;
}

const smartPhone = {
  name: 'smartPhone',
  label: 'Smart Phone Icon',
  svgText: svgText
}

export default smartPhone;
