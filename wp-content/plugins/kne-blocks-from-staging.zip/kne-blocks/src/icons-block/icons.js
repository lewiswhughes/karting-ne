import giftCard from './icons/giftCard.js';
import karting from './icons/karting.js';
import smartPhone from './icons/smartPhone.js';
import mapPin from './icons/mapPin.js';

const Icons = [ giftCard, karting, smartPhone, mapPin ];

export default Icons;
