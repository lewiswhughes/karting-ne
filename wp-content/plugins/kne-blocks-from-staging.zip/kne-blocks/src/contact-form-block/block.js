const { MediaUpload, PlainText, InspectorControls, ColorPalette, InnerBlocks, URLInput } = wp.editor;
const { registerBlockType } = wp.blocks;
const { PanelBody, Button, TextControl, SelectControl } = wp.components;
const { Fragment, createElement } = wp.element;

registerBlockType('kne/contact-form-block', {
  title: 'Contact Form Block',
  icon: 'heart',
  category: 'common',
  attributes: {
    formId: {
      type: 'integer'
    },
    formTitle: {
      type: 'string',
      default: 'Get in touch'
    }
  },

  edit( {attributes, setAttributes} ) {

    return[
      <InspectorControls>
        <PanelBody>
          <TextControl
            label="Form ID Number"
            type="number"
            value={ attributes.formId }
            onChange={ value => setAttributes({ formId: parseInt( value, 10 )})}
          />
          <TextControl
            label="Form Title"
            value={ attributes.formTitle }
            onChange={ value => setAttributes({ formTitle: value })}
          />
        </PanelBody>
      </InspectorControls>,
      <form class="fancy contact-us" method="post" action="" data-form-id={ attributes.formId }>
        <h3>{ attributes.formTitle }</h3>
        <div>
          <div class="left">
            <div>
              <input type="text" name="contact-name" id="contact-name" placeholder="Your name" required />
              <label for="contact-name">Your Name</label>
            </div>

            <div>
              <input class="hp" type="email" name="email" id="hp-email" placeholder="Your email" />
              <input type="email" name="contact-email" id="contact-email" placeholder="Your email" required />
              <label for="contact-email">Your E-mail</label>
            </div>

            <div>
              <input type="checkbox" name="contact-consent" id="contact-consent" required />
              <label for="contact-consent"><p>I understand that KNE may from time to time send me e-mails regarding offers and events at KNE, and I have read and agree with the terms set out in the KNE <a href="/privacy-policy">privacy policy</a>.</p></label>
            </div>
          </div>
          <div class="right">
            <div class="message-cont">
              <textarea name="contact-message" id="contact-message" placeholder="Your message" required></textarea>
              <label for="contact-message">Message</label>
            </div>
          </div>
        </div>

        <input class="contact-form-submit" type="submit" value="submit" />
      </form>
    ]
  },


  save( { attributes } ) {

    return (
      <form class="fancy contact-us" method="post" action="" id="contact-form" data-form-id={ attributes.formId }>
        <h3>{ attributes.formTitle }</h3>

        <div class="message-container"></div>

        <div>
          <div class="left">
            <div>
              <input type="text" name="contact-name" id="contact-name" placeholder="Your name" required />
              <label for="contact-name">Your Name</label>
            </div>

            <div>
              <input class="hp" type="email" name="email" id="hp-email" placeholder="Your email" />
              <input type="email" name="contact-email" id="contact-email" placeholder="Your email" required />
              <label for="contact-email">Your E-mail</label>
            </div>

            <div>
              <input type="checkbox" name="contact-consent" id="contact-consent" required />
              <label for="contact-consent"><p>I understand that KNE may from time to time send me e-mails regarding offers and events at KNE, and I have read and agree with the terms set out in the KNE <a href="/privacy-policy">privacy policy</a>.</p></label>
            </div>
          </div>
          <div class="right">
            <div class="message-cont">
              <textarea name="contact-message" id="contact-message" placeholder="Your message" required></textarea>
              <label for="contact-message">Message</label>
            </div>
          </div>
        </div>

        <input class="contact-form-submit" name="submit" type="submit" value="submit" />
      </form>
    )
  }

});
