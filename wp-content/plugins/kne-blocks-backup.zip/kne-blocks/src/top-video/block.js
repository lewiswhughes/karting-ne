const { InspectorControls, MediaUpload } = wp.editor;
const { registerBlockType } = wp.blocks;
const { PanelBody, TextControl, Button } = wp.components;
const { Fragment } = wp.element;

registerBlockType('kne/top-video', {
  title: 'Top Video',
  icon: 'heart',
  category: 'common',
  attributes: {
    videoUrl: {
      attribute: 'src',
      selector: 'video'
    },
    videoId: {
      attribute: 'id',
      selector: 'video'
    },
    imageUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageId: {
      attribute: 'id',
      selector: 'img'
    },

  },

  edit( {attributes, setAttributes } ) {

    const getVideoSource = () => {
      if(attributes.videoUrl) {
        return(
          attributes.videoUrl
        );
      } else {
        return 'http://clips.vorwaerts-gmbh.de/VfE_html5.mp4'
      }
    }

    const getImageSource = () => {
      if(attributes.imageUrl) {
        return(
          attributes.imageUrl
        );
      } else {
        return 'https://source.unsplash.com/random'
      }
    }

    const getVideoButton = (openEvent) => {
      if(attributes.videoUrl) {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Change video
          </Button>
        );
      } else {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Choose video
          </Button>
        );
      }
    };

    const getImageButton = (openEvent) => {
      if(attributes.imageUrl) {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Change background image
          </Button>
        );
      } else {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Choose background image
          </Button>
        );
      }
    };

    return (
      <div className="top-video-container">
        <h3>Top Video</h3>
        <div>
          <video
            src={ getVideoSource() }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ videoUrl: media.url, videoId: media.id }) }
            type="video"
            value={ attributes.videoId }
            render={ ({ open }) => getVideoButton(open) }
          />
          <p>{ attributes.videoUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource() }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ imageUrl: media.url, imageId: media.id }) }
            type="img"
            value={ attributes.imageId }
            render={ ({ open }) => getImageButton(open) }
          />
          <p>{ attributes.imageUrl }</p>
        </div>
      </div>
    )
  },


  save( { attributes } ) {

    return (
      <div className="top-video-container" style={{ backgroundImage: `url(${attributes.imageUrl})` }}>
        <button className="play" aria-label="Launches a modal that plays a video."></button>
        <div className="video-container">
          <button className="closeModal">Close X</button>
          <video controls>
            <source src={ attributes.videoUrl } />
          </video>
        </div>
      </div>
    )
  }


});
