const svgText = function( color ){
  return `<svg xmlns="http://www.w3.org/2000/svg" width="50.5" height="69.12" viewBox="0 0 50.5 69.12">
    <path id="Path_352" data-name="Path 352" d="M50.5,25.135a25.25,25.25,0,0,0-50.5,0A24.954,24.954,0,0,0,5.822,41.187L25.271,69.12,45,40.779a24.994,24.994,0,0,0,1.944-2.792l.2-.284h-.033A24.907,24.907,0,0,0,50.5,25.135m-13.1,0A12.624,12.624,0,1,1,24.777,12.568,12.6,12.6,0,0,1,37.4,25.135" fill="` + color + `"/>
  </svg>`;
}

const mapPin = {
  name: 'mapPin',
  label: 'Map Pin Icon',
  svgText: svgText
}

export default mapPin;
