import './style.scss';
import './editor.scss';

import './link-button/block.js';
import './product-block/block.js';
import './offers-carousel/block.js';
import './offers-list-block/block.js';
import './icons-block/block.js';
import './top-video/block.js';
import './main-splash/block.js';
import './detail-summary-block/block.js';
import './contact-form-block/block.js';
