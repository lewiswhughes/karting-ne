const { InspectorControls, InnerBlocks } = wp.editor;
const { registerBlockType } = wp.blocks;
const { withSelect } = wp.data;

registerBlockType( 'kne/offers-list-block', {
    title: 'Offers List Block',
    icon: 'heart',
    category: 'widgets',

    edit: withSelect( ( select ) => {
        return {
            posts: select( 'core' ).getEntityRecords( 'postType', 'offer' )
        };
    } )( ( { posts, className } ) => {

      if ( ! posts ) {
          return "Loading...";
      }

      if ( posts && posts.length === 0 ) {
          return "No offers";
      }

      let content = posts.map( (post) => {
        return <article className="offer">
                <h2>{ post.title.rendered }</h2>
                <p>{ post.acf.summary_text }</p>
              </article>
      })

      return <section className="offers-list">{ content }</section>;

    } ),

    save() {
        // Rendering in PHP
        return null;
    },
} );
