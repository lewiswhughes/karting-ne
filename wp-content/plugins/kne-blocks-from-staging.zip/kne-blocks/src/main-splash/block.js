const { InspectorControls, MediaUpload } = wp.editor;
const { registerBlockType } = wp.blocks;
const { PanelBody, TextControl, Button } = wp.components;
const { Fragment, createElement } = wp.element;

const phoneIcon = createElement('svg', { viewBox: "0 0 578.106 578.106" },
    createElement('path', { d: "M15.6,435.9l118.1-69.8h0.6c4.1-2.4,9.6-3.7,16.5-3.7c9.8,0,18.4,3.3,25.7,9.8l34.9,35.5	c0.8,0.8,2.1,1.5,4,2.1c1.8,0.6,3.2,0.9,4,0.9l7.6-1.5c5.1-1,12.4-4,22-8.9s21.5-12.5,35.8-22.9c14.3-10.4,30.6-25,49-43.8 c18.8-18.4,33.3-34.6,43.5-48.7c10.2-14.1,17.7-26,22.6-35.8c5.7-11,9.4-20.8,11-29.4c0-1.2-0.3-2.8-0.9-4.6s-1.3-3.2-2.1-4	l-30-30c-5.3-5.3-8.8-11.8-10.4-19.6c-1.6-7.8-0.6-14.9,3.1-21.4L436,16.1c2.9-4.5,6.3-8.3,10.4-11.3c4.1-3.1,8.8-4.6,14.1-4.6 c7.3,0,13.9,2.9,19.6,8.6l81.4,81.4c4.1,3.7,7.5,8.5,10.4,14.4c2.9,5.9,4.7,11.7,5.5,17.4c0,0.8,0.2,4.9,0.6,12.2	c0.4,7.3-0.4,17.4-2.4,30.3c-2,12.9-5.9,28.2-11.6,45.9c-5.7,17.7-14.3,37.5-25.7,59.4c-11.4,21.8-26.5,45.6-45.3,71.3 c-18.8,25.7-42.4,52.6-71,80.8c-35.9,36.3-69.8,64.9-101.6,85.7c-31.8,20.8-60.3,36.4-85.4,46.8c-25.1,10.4-46.3,16.9-63.6,19.6 s-29.9,4-37.6,4c-3.3,0-5.9-0.1-8-0.3c-2-0.2-3.3-0.3-3.7-0.3c-5.7-0.8-11.5-2.7-17.4-5.5c-5.9-2.9-10.7-6.3-14.4-10.4L8.8,480.6	c-6.9-6.9-9.8-15.1-8.6-24.5C1.9,448,7,441.2,15.6,435.9z", fill: "#ffffff"})
  );

registerBlockType('kne/main-splash', {
  title: 'KNE Main Splash',
  icon: 'heart',
  category: 'common',
  attributes: {
    header: {
      type: 'text'
    },
    subheader: {
      type: 'text'
    },
    videoUrl: {
      attribute: 'src',
      selector: 'video'
    },
    videoId: {
      attribute: 'id',
      selector: 'video'
    },
    imageOneUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageOneId: {
      attribute: 'id',
      selector: 'img'
    },
    imageTwoUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageTwoId: {
      attribute: 'id',
      selector: 'img'
    },
    imageThreeUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageThreeId: {
      attribute: 'id',
      selector: 'img'
    },
    imageFourUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageFourId: {
      attribute: 'id',
      selector: 'img'
    },
    imageFiveUrl: {
      attribute: 'src',
      selector: 'img'
    },
    imageFiveId: {
      attribute: 'id',
      selector: 'img'
    }
  },

  edit( {attributes, setAttributes } ) {

    const getVideoSource = () => {
      if(attributes.videoUrl) {
        return(
          attributes.videoUrl
        );
      } else {
        return 'http://clips.vorwaerts-gmbh.de/VfE_html5.mp4'
      }
    }

    const getImageSource = (attribute) => {
      if(attribute) {
        return(
          attribute
        );
      } else {
        return 'https://source.unsplash.com/random'
      }
    }


    const getVideoButton = (openEvent) => {
      if(attributes.videoUrl) {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Change video
          </Button>
        );
      } else {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Choose video
          </Button>
        );
      }
    };

    const getImageButton = (openEvent, attribute, number) => {
      if(attribute) {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Change image {number}
          </Button>
        );
      } else {
        return (
          <Button
            onClick={ openEvent }
            className="button button-large"
          >
            Choose image {number}
          </Button>
        );
      }
    };

    return [
      <InspectorControls>
        <TextControl
          label='Header'
          value={ attributes.header }
          onChange={ (value) => {
            setAttributes({ header: value });
          } }
        />
        <TextControl
          label='Sub-header'
          value={ attributes.subheader }
          onChange={ (value) => {
            setAttributes({ subheader: value });
          } }
        />
      </InspectorControls>,
      <div className="main-splash">
        <h3>Main Splash</h3>
        <div>
          <video
            src={ getVideoSource() }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ videoUrl: media.url, videoId: media.id }) }
            type="video"
            value={ attributes.videoId }
            render={ ({ open }) => getVideoButton(open) }
          />
          <p>{ attributes.videoUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource( attributes.imageOneUrl ) }
            width="300"
          />
          <MediaUpload
            onSelect={ media => { console.log(media); setAttributes({ imageOneUrl: media.url, imageOneId: media.id }) } }
            type="img"
            value={ attributes.imageOneId }
            render={ ({ open }) => getImageButton(open, attributes.imageOneId, 'one') }
          />
          <p>{ attributes.imageOneUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource( attributes.imageTwoUrl ) }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ imageTwoUrl: media.url, imageTwoId: media.id }) }
            type="img"
            value={ attributes.imageTwoId }
            render={ ({ open }) => getImageButton(open, attributes.imageTwoId, 'two') }
          />
          <p>{ attributes.imageTwoUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource( attributes.imageThreeUrl ) }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ imageThreeUrl: media.url, imageThreeId: media.id }) }
            type="img"
            value={ attributes.imageThreeId }
            render={ ({ open }) => getImageButton(open, attributes.imageThreeId, 'three') }
          />
          <p>{ attributes.imageThreeUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource( attributes.imageFourUrl ) }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ imageFourUrl: media.url, imageFourId: media.id }) }
            type="img"
            value={ attributes.imageFourId }
            render={ ({ open }) => getImageButton(open, attributes.imageFourId, 'four') }
          />
          <p>{ attributes.imageFourUrl }</p>
        </div>
        <div>
          <img
            src={ getImageSource( attributes.imageFiveUrl ) }
            width="300"
          />
          <MediaUpload
            onSelect={ media => setAttributes({ imageFiveUrl: media.url, imageFiveId: media.id }) }
            type="img"
            value={ attributes.imageFiveId }
            render={ ({ open }) => getImageButton(open, attributes.imageFiveId, 'five') }
          />
          <p>{ attributes.imageFiveUrl }</p>
        </div>
      </div>
    ]
  },


  save( { attributes } ) {

    return (
      <section className="kne-main-splash">
        <div><img src={ attributes.imageOneUrl } /></div>
        <div className="video-container">
          <button className="stop" aria-label="Stops and hides the video.">Close video</button>
          <video muted poster={ attributes.imageOneUrl }>
            <source src={ attributes.videoUrl } />
          </video>
        </div>
        <div><img src={ attributes.imageTwoUrl } /></div>
        <div>
          <img src={ attributes.imageThreeUrl } />
          <div><img src={ attributes.imageFourUrl } /></div>
        </div>
        <div></div> 
        <div><img src={ attributes.imageFiveUrl } /></div>
        <div></div>
        <div></div>
        <h1>{ attributes.header }</h1>
        <p className="subheader">{ attributes.subheader }</p>
        <div className="button-container">
          <button className="play" aria-label="Plays a video."></button>
          <a className="call-us link_button next" href="/booking-start/">Book Now</a>
        </div>
      </section>
    )
  }


});
