const { PlainText, InspectorControls, InnerBlocks } = wp.editor;
const { registerBlockType } = wp.blocks;

registerBlockType('kne/detail-summary-block', {
  title: 'Detail Summary Block',
  icon: 'heart',
  category: 'common',
  attributes: {
    summary: {
      type: 'text',
      source: 'text'
    },
  },

  edit( {attributes, className, setAttributes} ) {

    return(
      <div className="detail">
        <div className="summary">
          <PlainText
            onChange={ content => setAttributes({ summary: content }) }
            value={ attributes.summary }
            placeholder="Summary text"
          />
        </div>
        <InnerBlocks />
      </div>
    )
  },


  save( { attributes, className } ) {

    return (
      <details className={ className }>
        <summary>
          { attributes.summary }
        </summary>
        <InnerBlocks.Content />
      </details>
    );

  }


});
