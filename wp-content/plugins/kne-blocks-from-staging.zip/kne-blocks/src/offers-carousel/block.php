<?php
// block.php

function render_block_offers_carousel( $attributes, $content ) {

    $offer_content = '';

    $args = array(
      'post_type' => 'offer'
    );
    $offers_query = new WP_Query( $args );
    $offers = $offers_query->posts;

    foreach( $offers as $offer ){
      $offer_id = $offer->ID;
      $offer_content.= '<article class="carousel-card">';
      $offer_content.= '<a href="/offers"></a>';
      $offer_content.='<h2>'.$offer->post_title.'</h2>';
      $offer_content.='<p>'.get_field( 'summary_text', $offer_id ).'</p>';
      $offer_content.='</article>';
    }

    return '<section class="offers-carousel card-carousel">
              <button class="last-card">&lt;</button>
              <div class="card-container">'.$offer_content.'</div>
              <button class="next-card">&gt;</button>
            </section>';
}

register_block_type( 'kne/offers-carousel', array(
    'render_callback' => 'render_block_offers_carousel',
) );
