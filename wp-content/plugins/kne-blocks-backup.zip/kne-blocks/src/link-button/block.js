const { URLInput, RichText, InspectorControls, ColorPalette } = wp.editor;
const { registerBlockType } = wp.blocks;
const { PanelBody, TextControl, Dashicon, IconButton } = wp.components;
const { Fragment } = wp.element;

registerBlockType('kne/link-button', {
  title: 'Link Button',
  icon: 'heart',
  category: 'common',
  attributes: {
    url: {
  		type: 'string',
  		source: 'attribute',
  		selector: 'a',
  		attribute: 'href',
  	},
    linkText: {
      type: 'string',
      source: 'html',
      selector: 'a'
    },
    // bgColor: {
    //   type: 'string',
    //   default: null
    // },
    // fontColor: {
    //   type: 'string',
    //   default: null
    // }
  },

  edit( {attributes, setAttributes, isSelected } ) {

    const styles = {}
    //if bgImage
    // if(attributes.bgColor){
    //   styles.backgroundColor = attributes.bgColor;
    // }
    // if(attributes.fontColor){
    //   styles.color = attributes.fontColor;
    // };

    return (
      <Fragment>
        <RichText
					placeholder="Add text..."
          value={attributes.linkText}
          onChange={ (value) => setAttributes({ linkText: value })}
          formattingControls={ ['bold', 'italic'] }
          style={ styles }
				/>
        { isSelected && (
					<form
						className="block-library-button__inline-link"
						onSubmit={ ( event ) => event.preventDefault() }>
						<Dashicon icon="admin-links" />
						<URLInput
							value={ attributes.url }
							onChange={ ( value ) => setAttributes( { url: value } ) }
						/>
						<IconButton icon="editor-break" label="Apply" type="submit" />
					</form>
				) }
      </Fragment>
    );
  },


  save( { attributes } ) {

    const styles = {}
    // //if bgImage
    // if(attributes.bgColor){
    //   styles.backgroundColor = attributes.bgColor;
    // }
    // if(attributes.fontColor){
    //   styles.color = attributes.fontColor;
    // };

    return (
      <RichText.Content
        tagName="a"
        href={ attributes.url }
        style={ styles }
        value={ attributes.linkText }
      />
    );
  }


});
